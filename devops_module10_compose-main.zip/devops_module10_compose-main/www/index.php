<html>
 <head>
  <title>Test PHP</title>
 </head>
 <body>
 <?php echo '<p>It works!</p>'; ?>
 </body>
</html>
